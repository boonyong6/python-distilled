print("bar")
