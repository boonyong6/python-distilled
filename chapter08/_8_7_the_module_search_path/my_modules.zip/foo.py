print("foo")
